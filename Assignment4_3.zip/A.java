
public class A extends B{

	public void test(){
		System.out.println("Class A");
		super.test();	/*Calling method of class B */
	}
	
	public static void main(String[] args) {
	A a = new A();
	a.test();
	}
}

/* Solution */
/* The correct answer is :
 * f. It is not possible to invoke test() method defined in C from a method in A.*/

/* In this way, we can only invoke the test() method of
 * Class B into class A. Since class B is inheriting class C,
 * test() method of class C can be used in class B not in class A.
 * It is not possible to invoke test() method defined in C from a method in A." */
