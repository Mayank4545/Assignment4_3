
public class C {

	public void test(){
		System.out.println("Class C");
	}
}
