
public class B extends C{

	public void test(){
		System.out.println("Class B");
	}
}
